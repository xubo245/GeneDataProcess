更多代码请见：https://github.com/xubo245
	
基因数据处理系列之cs-bwamem

# 1.解释
##1.1


# 2.代码
##2.1

# 3.结果
##3.1



参考

		【1】https://github.com/xubo245
		【2】http://blog.csdn.net/xubo245/
