（1）pair1.fq》sai

```
	bwa aln GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired1.fq >g38L100c10000000Nhs20Paired1.sai
```

pair1记录：

```
	
	hadoop@Master:~/cloud/adam/xubo/data/GRCH38Sub/cs-bwamem$ bwa aln GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired1.fq >g38L100c10000000Nhs20Paired1.sai
	[bwa_aln] 17bp reads: max_diff = 2
	[bwa_aln] 38bp reads: max_diff = 3
	[bwa_aln] 64bp reads: max_diff = 4
	[bwa_aln] 93bp reads: max_diff = 5
	[bwa_aln] 124bp reads: max_diff = 6
	[bwa_aln] 157bp reads: max_diff = 7
	[bwa_aln] 190bp reads: max_diff = 8
	[bwa_aln] 225bp reads: max_diff = 9
	[bwa_aln_core] calculate SA coordinate... 40.82 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 262144 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.14 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 524288 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.22 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 786432 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.27 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1048576 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.83 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1310720 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.88 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1572864 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.32 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1835008 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.39 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2097152 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.87 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2359296 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.12 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2621440 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.95 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2883584 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.28 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3145728 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.28 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3407872 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.13 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3670016 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.00 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3932160 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.15 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4194304 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.36 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4456448 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.90 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4718592 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.05 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4980736 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.08 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5242880 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 42.93 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5505024 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.28 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5767168 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.39 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6029312 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.11 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6291456 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.47 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6553600 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.78 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6815744 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.86 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7077888 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.95 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7340032 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 41.03 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7602176 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.81 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7864320 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.02 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8126464 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.78 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8388608 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 40.83 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8650752 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.32 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8912896 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 43.34 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 9175040 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 12.48 sec
	[bwa_aln_core] write to the disk... 0.01 sec
	[bwa_aln_core] 9256331 sequences have been processed.
	[main] Version: 0.7.13-r1126
	[main] CMD: bwa aln GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired1.fq
	[main] Real time: 1518.448 sec; CPU: 1496.862 sec

```

(2)pair2.fq>sai

```
	
	hadoop@Master:~/cloud/adam/xubo/data/GRCH38Sub/cs-bwamem$ bwa aln GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired2.fq >g38L100c10000000Nhs20Paired2.sai
	[bwa_aln] 17bp reads: max_diff = 2
	[bwa_aln] 38bp reads: max_diff = 3
	[bwa_aln] 64bp reads: max_diff = 4
	[bwa_aln] 93bp reads: max_diff = 5
	[bwa_aln] 124bp reads: max_diff = 6
	[bwa_aln] 157bp reads: max_diff = 7
	[bwa_aln] 190bp reads: max_diff = 8
	[bwa_aln] 225bp reads: max_diff = 9
	[bwa_aln_core] calculate SA coordinate... 53.65 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 262144 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.61 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 524288 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.88 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 786432 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.31 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1048576 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.92 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1310720 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.49 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1572864 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.12 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 1835008 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.36 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2097152 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.36 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2359296 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.00 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2621440 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.90 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 2883584 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.42 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3145728 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.77 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3407872 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.13 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3670016 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.01 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 3932160 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.99 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4194304 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.55 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4456448 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.29 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4718592 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.02 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 4980736 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.09 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5242880 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.99 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5505024 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.41 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 5767168 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 53.68 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6029312 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 56.68 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6291456 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.49 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6553600 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.37 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 6815744 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.05 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7077888 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 57.08 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7340032 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.23 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7602176 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 53.93 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 7864320 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.36 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8126464 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 53.86 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8388608 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 53.96 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8650752 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.55 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 8912896 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 54.07 sec
	[bwa_aln_core] write to the disk... 0.03 sec
	[bwa_aln_core] 9175040 sequences have been processed.
	[bwa_aln_core] calculate SA coordinate... 16.78 sec
	[bwa_aln_core] write to the disk... 0.01 sec
	[bwa_aln_core] 9256331 sequences have been processed.
	[main] Version: 0.7.13-r1126
	[main] CMD: bwa aln GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired2.fq
	[main] Real time: 2003.658 sec; CPU: 1980.403 sec

```

(3) 匹配：

```
	
	hadoop@Master:~/cloud/adam/xubo/data/GRCH38Sub/cs-bwamem$ bwa sampe GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired1.sai g38L100c10000000Nhs20Paired2.sai g38L100c10000000Nhs20Paired1.fq g38L100c10000000Nhs20Paired2.fq > g38L100c10000000Nhs20Paired12.bwa.sam
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244114 pairs: 199.440 +/- 9.960
	[infer_isize] skewness: -0.004; kurtosis: -0.071; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.95 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5419 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 842 out of 842 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.18 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.88 sec
	[bwa_sai2sam_pe_core] 262144 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243856 pairs: 199.509 +/- 9.944
	[infer_isize] skewness: -0.008; kurtosis: -0.092; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 8.28 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5442 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 853 out of 853 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 16 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.27 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 524288 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243858 pairs: 199.511 +/- 9.954
	[infer_isize] skewness: -0.004; kurtosis: -0.087; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 8.26 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5510 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 878 out of 878 Q17 singletons are mated.
	[bwa_paired_sw] 18 out of 19 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.16 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 786432 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244096 pairs: 199.499 +/- 9.947
	[infer_isize] skewness: 0.006; kurtosis: -0.096; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.49 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5362 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 843 out of 843 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 15 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.13 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.92 sec
	[bwa_sai2sam_pe_core] 1048576 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244039 pairs: 199.531 +/- 9.924
	[infer_isize] skewness: 0.004; kurtosis: -0.090; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 8.21 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5477 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 768 out of 768 Q17 singletons are mated.
	[bwa_paired_sw] 19 out of 20 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.15 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.92 sec
	[bwa_sai2sam_pe_core] 1310720 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243833 pairs: 199.476 +/- 9.941
	[infer_isize] skewness: 0.002; kurtosis: -0.091; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 8.00 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5493 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 834 out of 834 Q17 singletons are mated.
	[bwa_paired_sw] 12 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.13 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 1572864 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244057 pairs: 199.503 +/- 9.933
	[infer_isize] skewness: -0.001; kurtosis: -0.096; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.78 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5364 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 866 out of 866 Q17 singletons are mated.
	[bwa_paired_sw] 9 out of 10 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.15 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.46 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 1835008 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244027 pairs: 199.481 +/- 9.980
	[infer_isize] skewness: -0.000; kurtosis: -0.109; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.54 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5430 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 804 out of 804 Q17 singletons are mated.
	[bwa_paired_sw] 9 out of 11 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.23 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.83 sec
	[bwa_sai2sam_pe_core] 2097152 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243971 pairs: 199.475 +/- 9.957
	[infer_isize] skewness: 0.002; kurtosis: -0.085; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 8.24 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5412 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 833 out of 833 Q17 singletons are mated.
	[bwa_paired_sw] 15 out of 15 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.18 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 2359296 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244088 pairs: 199.514 +/- 9.948
	[infer_isize] skewness: 0.003; kurtosis: -0.093; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.45 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5521 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 853 out of 853 Q17 singletons are mated.
	[bwa_paired_sw] 7 out of 9 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.13 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 2621440 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244054 pairs: 199.492 +/- 9.961
	[infer_isize] skewness: 0.001; kurtosis: -0.080; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.70 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5386 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 825 out of 825 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 10 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.23 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.89 sec
	[bwa_sai2sam_pe_core] 2883584 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243926 pairs: 199.507 +/- 9.951
	[infer_isize] skewness: 0.002; kurtosis: -0.093; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.60 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5473 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 831 out of 831 Q17 singletons are mated.
	[bwa_paired_sw] 15 out of 15 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 3145728 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243802 pairs: 199.476 +/- 9.958
	[infer_isize] skewness: 0.006; kurtosis: -0.089; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.54 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5572 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 817 out of 817 Q17 singletons are mated.
	[bwa_paired_sw] 17 out of 18 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.13 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.83 sec
	[bwa_sai2sam_pe_core] 3407872 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243845 pairs: 199.518 +/- 9.945
	[infer_isize] skewness: 0.000; kurtosis: -0.083; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.26 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5518 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 851 out of 851 Q17 singletons are mated.
	[bwa_paired_sw] 8 out of 9 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.92 sec
	[bwa_sai2sam_pe_core] 3670016 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243929 pairs: 199.488 +/- 9.950
	[infer_isize] skewness: -0.006; kurtosis: -0.094; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.69 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5433 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 872 out of 872 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 10 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.82 sec
	[bwa_sai2sam_pe_core] 3932160 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244036 pairs: 199.483 +/- 9.938
	[infer_isize] skewness: -0.000; kurtosis: -0.097; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.29 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5428 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 807 out of 807 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 11 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.42 sec
	[bwa_sai2sam_pe_core] print alignments... 1.86 sec
	[bwa_sai2sam_pe_core] 4194304 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243878 pairs: 199.466 +/- 9.940
	[infer_isize] skewness: -0.003; kurtosis: -0.092; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.54 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5586 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 858 out of 858 Q17 singletons are mated.
	[bwa_paired_sw] 11 out of 11 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.22 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 4456448 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243722 pairs: 199.534 +/- 9.949
	[infer_isize] skewness: 0.001; kurtosis: -0.081; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.68 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5512 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 856 out of 856 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 15 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 4718592 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244102 pairs: 199.510 +/- 9.928
	[infer_isize] skewness: 0.007; kurtosis: -0.081; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.57 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5313 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 819 out of 819 Q17 singletons are mated.
	[bwa_paired_sw] 14 out of 14 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.17 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.80 sec
	[bwa_sai2sam_pe_core] 4980736 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243994 pairs: 199.463 +/- 9.955
	[infer_isize] skewness: 0.001; kurtosis: -0.104; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.40 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5420 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 861 out of 861 Q17 singletons are mated.
	[bwa_paired_sw] 16 out of 16 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.44 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 5242880 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243996 pairs: 199.498 +/- 9.936
	[infer_isize] skewness: -0.004; kurtosis: -0.083; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.99 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5377 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 842 out of 842 Q17 singletons are mated.
	[bwa_paired_sw] 8 out of 12 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.15 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.42 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 5505024 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243784 pairs: 199.485 +/- 9.950
	[infer_isize] skewness: 0.003; kurtosis: -0.095; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.40 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5417 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 890 out of 890 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.13 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 5767168 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244130 pairs: 199.473 +/- 9.963
	[infer_isize] skewness: 0.006; kurtosis: -0.099; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.67 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5340 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 840 out of 840 Q17 singletons are mated.
	[bwa_paired_sw] 12 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 6029312 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244004 pairs: 199.527 +/- 9.940
	[infer_isize] skewness: -0.004; kurtosis: -0.090; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.58 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5332 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 874 out of 874 Q17 singletons are mated.
	[bwa_paired_sw] 14 out of 17 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.87 sec
	[bwa_sai2sam_pe_core] 6291456 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243871 pairs: 199.521 +/- 9.953
	[infer_isize] skewness: 0.002; kurtosis: -0.090; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.76 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5438 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 849 out of 849 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 14 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.92 sec
	[bwa_sai2sam_pe_core] 6553600 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243984 pairs: 199.469 +/- 9.936
	[infer_isize] skewness: -0.001; kurtosis: -0.087; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.55 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5204 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 872 out of 872 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 6815744 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243821 pairs: 199.507 +/- 9.948
	[infer_isize] skewness: 0.004; kurtosis: -0.088; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.72 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5387 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 821 out of 821 Q17 singletons are mated.
	[bwa_paired_sw] 12 out of 13 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 7077888 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244057 pairs: 199.468 +/- 9.932
	[infer_isize] skewness: -0.001; kurtosis: -0.100; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.51 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5473 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 819 out of 819 Q17 singletons are mated.
	[bwa_paired_sw] 10 out of 10 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.92 sec
	[bwa_sai2sam_pe_core] 7340032 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243999 pairs: 199.497 +/- 9.932
	[infer_isize] skewness: 0.003; kurtosis: -0.098; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.64 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5273 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 846 out of 846 Q17 singletons are mated.
	[bwa_paired_sw] 9 out of 12 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 7602176 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 244005 pairs: 199.491 +/- 9.930
	[infer_isize] skewness: -0.001; kurtosis: -0.113; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.10 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5347 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 830 out of 830 Q17 singletons are mated.
	[bwa_paired_sw] 17 out of 20 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 7864320 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243487 pairs: 199.504 +/- 9.930
	[infer_isize] skewness: 0.003; kurtosis: -0.096; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.73 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5565 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 846 out of 846 Q17 singletons are mated.
	[bwa_paired_sw] 23 out of 23 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 8126464 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243895 pairs: 199.494 +/- 9.962
	[infer_isize] skewness: -0.002; kurtosis: -0.096; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.54 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5427 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 831 out of 831 Q17 singletons are mated.
	[bwa_paired_sw] 18 out of 18 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 8388608 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243919 pairs: 199.499 +/- 9.956
	[infer_isize] skewness: -0.005; kurtosis: -0.084; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.73 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5456 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 847 out of 847 Q17 singletons are mated.
	[bwa_paired_sw] 14 out of 15 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.12 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.90 sec
	[bwa_sai2sam_pe_core] 8650752 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243745 pairs: 199.521 +/- 9.947
	[infer_isize] skewness: 0.002; kurtosis: -0.076; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.68 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5409 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 862 out of 862 Q17 singletons are mated.
	[bwa_paired_sw] 21 out of 22 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.45 sec
	[bwa_sai2sam_pe_core] print alignments... 1.91 sec
	[bwa_sai2sam_pe_core] 8912896 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 199, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 243763 pairs: 199.499 +/- 9.938
	[infer_isize] skewness: -0.005; kurtosis: -0.101; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 7.43 sec
	[bwa_sai2sam_pe_core] changing coordinates of 5403 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 870 out of 870 Q17 singletons are mated.
	[bwa_paired_sw] 13 out of 14 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.11 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.43 sec
	[bwa_sai2sam_pe_core] print alignments... 1.81 sec
	[bwa_sai2sam_pe_core] 9175040 sequences have been processed.
	[bwa_sai2sam_pe_core] convert to sequence coordinate... 
	[infer_isize] (25, 50, 75) percentile: (193, 200, 206)
	[infer_isize] low and high boundaries: 167 and 232 for estimating avg and std
	[infer_isize] inferred external isize from 75635 pairs: 199.481 +/- 9.970
	[infer_isize] skewness: -0.015; kurtosis: -0.109; ap_prior: 1.00e-05
	[infer_isize] inferred maximum insert size: 266 (6.70 sigma)
	[bwa_sai2sam_pe_core] time elapses: 2.59 sec
	[bwa_sai2sam_pe_core] changing coordinates of 1651 alignments.
	[bwa_sai2sam_pe_core] align unmapped mate...
	[bwa_paired_sw] 259 out of 259 Q17 singletons are mated.
	[bwa_paired_sw] 3 out of 3 Q17 discordant pairs are fixed.
	[bwa_sai2sam_pe_core] time elapses: 0.05 sec
	[bwa_sai2sam_pe_core] refine gapped alignments... 0.14 sec
	[bwa_sai2sam_pe_core] print alignments... 0.59 sec
	[bwa_sai2sam_pe_core] 9256331 sequences have been processed.
	[main] Version: 0.7.13-r1126
	[main] CMD: bwa sampe GRCH38BWAindex/GRCH38chr1L3556522.fasta g38L100c10000000Nhs20Paired1.sai g38L100c10000000Nhs20Paired2.sai g38L100c10000000Nhs20Paired1.fq g38L100c10000000Nhs20Paired2.fq
	[main] Real time: 562.819 sec; CPU: 386.586 sec

```